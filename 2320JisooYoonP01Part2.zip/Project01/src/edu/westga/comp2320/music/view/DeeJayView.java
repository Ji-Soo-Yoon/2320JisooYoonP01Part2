package edu.westga.comp2320.music.view;

import edu.westga.comp2320.music.model.Album;

/**
 * The DeeJayView class represents the textual user interface for the application.
 * It keeps track of an Album object and displays messages to the user.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class DeeJayView {
    private Album album;

    /**
     * Constructs a DeeJayView object.
     */
    public DeeJayView() {
    }

    /**
     * Runs the textual user interface.
     * Displays a welcome message.
     */
    public void run() {
        System.out.println("Welcome to the DeeJay Music Program!");
    }

    /**
     * Gets the album associated with this view.
     * 
     * @return the album
     */
    public Album getAlbum() {
        return this.album;
    }

    /**
     * Sets the album for this view.
     * 
     * @param album the album to set
     */
    public void setAlbum(Album album) {
        this.album = album;
    }
}