package edu.westga.comp2320.music.model;

/**
 * The Song class represents a song with a title, length, and current playback position.
 * It provides methods to manipulate and retrieve song information.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class Song {
    private String title;
    private int lengthInSeconds;
    private int currentTimePosition;

    /**
     * Constructs a Song with a specified title, length, and current time position.
     * 
     * @param title               the title of the song
     * @param lengthInSeconds     the total length of the song in seconds
     * @param currentTimePosition the current playback position in seconds
     */
    public Song(String title, int lengthInSeconds, int currentTimePosition) {
        if (title == null || title.isEmpty()) {
            throw new IllegalArgumentException("Title cannot be null or empty");
        }
        if (lengthInSeconds <= 0) {
            throw new IllegalArgumentException("Song length must be greater than zero");
        }
        if (currentTimePosition < 0 || currentTimePosition > lengthInSeconds) {
            throw new IllegalArgumentException("Invalid current time position");
        }
        
        this.title = title;
        this.lengthInSeconds = lengthInSeconds;
        this.currentTimePosition = currentTimePosition;
    }

    /**
     * Constructs a Song with a specified title and length.
     * The current time position is set to 0.
     * 
     * @param title           the title of the song
     * @param lengthInSeconds the total length of the song in seconds
     */
    public Song(String title, int lengthInSeconds) {
        this(title, lengthInSeconds, 0);
    }

    /**
     * Gets the title of the song.
     * 
     * @return the song title
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * Gets the total length of the song in seconds.
     * 
     * @return the length of the song
     */
    public int getLength() {
        return this.lengthInSeconds;
    }

    /**
     * Gets the current playback position of the song.
     * 
     * @return the current playback position in seconds
     */
    public int getCurrentTime() {
        return this.currentTimePosition;
    }

    /**
     * Simulates listening to the song for a given number of seconds.
     * If the requested time exceeds the song's length, it sets the time to the song's end.
     * 
     * @param seconds the number of seconds to listen to
     */
    public void listenToSong(int seconds) {
        if (seconds < 0) {
            throw new IllegalArgumentException("Listening time cannot be negative");
        }
        
        this.currentTimePosition += seconds;
        if (this.currentTimePosition > this.lengthInSeconds) {
            this.currentTimePosition = this.lengthInSeconds;
        }
    }

    /**
     * Restarts the song by resetting the current playback position to 0.
     */
    public void restartSong() {
        this.currentTimePosition = 0;
    }

    /**
     * Gets the remaining time of the song.
     * 
     * @return the time remaining in seconds
     */
    public int getTimeRemaining() {
        return this.lengthInSeconds - this.currentTimePosition;
    }

    /**
     * Returns a string representation of the song.
     * 
     * @return a string containing the song title, length, and current time position
     */
    @Override
    public String toString() {
        return "Song: " + this.title + ", Length: " + this.lengthInSeconds + "s, Current Position: " + this.currentTimePosition + "s";
    }
}