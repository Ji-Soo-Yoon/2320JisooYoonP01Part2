package edu.westga.comp2320.music.model;

import java.util.ArrayList;
import java.util.List;

/**
 * The Album class represents a collection of songs owned by a person.
 * It provides methods to manage and retrieve information about the songs.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class Album {
    private String albumName;
    private List<Song> songs;

    /**
     * Constructs an Album with the specified name and initializes the song collection.
     * 
     * @param albumName the name of the album
     */
    public Album(String albumName) {
        if (albumName == null || albumName.isEmpty()) {
            throw new IllegalArgumentException("Album name cannot be null or empty");
        }
        this.albumName = albumName;
        this.songs = new ArrayList<>();
    }

    /**
     * Adds a song to the album.
     * 
     * @param song the song to be added
     */
    public void add(Song song) {
        if (song == null) {
            throw new IllegalArgumentException("Song cannot be null");
        }
        this.songs.add(song);
    }

    /**
     * Simulates listening to a song in the album.
     * 
     * @param index the index of the song in the album
     * @param seconds the number of seconds to listen to
     */
    public void listenToSong(int index, int seconds) {
        if (index < 0 || index >= this.songs.size()) {
            throw new IndexOutOfBoundsException("Invalid song index");
        }
        this.songs.get(index).listenToSong(seconds);
    }

    /**
     * Resets all songs to the beginning.
     * 
     * @return a string confirming the restart of all songs
     */
    public String restartAllSongs() {
        StringBuilder sb = new StringBuilder("Restarting the following songs:\n");
        for (Song song : this.songs) {
            song.restartSong();
            sb.append(song.getTitle()).append("\n");
        }
        return sb.toString();
    }

    /**
     * Returns the number of songs in the album.
     * 
     * @return the number of songs
     */
    public int size() {
        return this.songs.size();
    }

    /**
     * Calculates the total length of all songs in the album.
     * 
     * @return the total length in seconds
     */
    public int getTotalLength() {
        int totalLength = 0;
        for (Song song : this.songs) {
            totalLength += song.getLength();
        }
        return totalLength;
    }

    /**
     * Calculates the total remaining time of all songs in the album.
     * 
     * @return the total remaining time in seconds
     */
    public int getTimeRemaining() {
        int totalRemaining = 0;
        for (Song song : this.songs) {
            totalRemaining += song.getTimeRemaining();
        }
        return totalRemaining;
    }

    /**
     * Gets the album name.
     * 
     * @return the album name
     */
    public String getAlbumName() {
        return this.albumName;
    }

    /**
     * Returns a string representation of the album including all songs and summary information.
     * 
     * @return the album details
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Album: " + this.albumName + "\n");
        for (Song song : this.songs) {
            sb.append(song.toString()).append("\n");
        }
        sb.append("Total Length: ").append(this.getTotalLength()).append("s\n");
        sb.append("Total Time Remaining: ").append(this.getTimeRemaining()).append("s\n");
        return sb.toString();
    }
}