package edu.westga.comp2320.music.test.deejayview;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import edu.westga.comp2320.music.view.DeeJayView;
import edu.westga.comp2320.music.model.Album;

/**
 * JUnit test class for the getAlbum() and setAlbum() methods of DeeJayView.
 * Ensures proper setting and retrieval of the album.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class TestDeeJayView {

    /**
     * Test getAlbum() should return null when no album is set.
     */
    @Test
    public void testGetAlbumShouldReturnNullInitially() {
        // Arrange
        DeeJayView view = new DeeJayView();

        // Act & Assert
        assertNull(view.getAlbum(), "getAlbum() should return null when no album is set");
    }

    /**
     * Test setAlbum() should correctly assign an album, and getAlbum() should retrieve it.
     */
    @Test
    public void testSetAlbumShouldStoreAndReturnCorrectAlbum() {
        // Arrange
        DeeJayView view = new DeeJayView();
        Album album = new Album("Test Album");

        // Act
        view.setAlbum(album);

        // Assert
        assertEquals(album, view.getAlbum(), "getAlbum() should return the album set by setAlbum()");
    }
}

