package edu.westga.comp2320.music.test.album;

import static org.junit.jupiter.api.Assertions.*;

import edu.westga.comp2320.music.model.Song;
import edu.westga.comp2320.music.model.Album;
import org.junit.jupiter.api.Test;

public class TestAdd {

    @Test
    public void testAddSongToAlbum() {
        // Arrange
        Album album = new Album("Greatest Hits");
        Song song1 = new Song("Song 1", 180);
        Song song2 = new Song("Song 2", 210);

        // Act
        album.add(song1);
        album.add(song2);

        // Assert
        assertEquals(2, album.size(), "The album should contain 2 songs.");
        assertTrue(album.toString().contains("Song 1"), "The album should contain Song 1.");
        assertTrue(album.toString().contains("Song 2"), "The album should contain Song 2.");
    }

    @Test
    public void testAddNullSongToAlbum() {
        // Arrange
        Album album = new Album("Classic Album");

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            album.add(null);
        });
        assertEquals("Song cannot be null", exception.getMessage(), "The exception message should be 'Song cannot be null'");
    }
}
