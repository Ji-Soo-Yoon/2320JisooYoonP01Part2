package edu.westga.comp2320.music.test.album;

import static org.junit.jupiter.api.Assertions.*;

import edu.westga.comp2320.music.model.Song;
import edu.westga.comp2320.music.model.Album;
import org.junit.jupiter.api.Test;

public class TestListenToSong {

    @Test
    public void testListenToSongValidIndex() {
        // Initialize a new album and songs
        Album album = new Album("Greatest Hits");
        Song song1 = new Song("Song 1", 180);
        Song song2 = new Song("Song 2", 240);
        
        album.add(song1);
        album.add(song2);

        // Act: Listen to 60 seconds of Song 1
        album.listenToSong(0, 60);

        // Assert: Song 1 should have its current position updated to 60 seconds
        assertEquals(60, song1.getCurrentTime(), "The current time position of Song 1 should be 60 seconds.");
    }

    @Test
    public void testListenToSongValidIndexWithExceedingTime() {
        // Initialize a new album and songs
        Album album = new Album("Greatest Hits");
        Song song1 = new Song("Song 1", 180);
        Song song2 = new Song("Song 2", 240);
        
        album.add(song1);
        album.add(song2);

        // Act: Listen to 200 seconds of Song 1 (total length is 180, should cap at 180)
        album.listenToSong(0, 200);

        // Assert: Song 1 should have its current position updated to 180 seconds (max length)
        assertEquals(180, song1.getCurrentTime(), "The current time position of Song 1 should be capped at the song length.");
    }

    @Test
    public void testListenToSongWithNegativeTime() {
        // Initialize a new album and songs
        Album album = new Album("Greatest Hits");
        Song song1 = new Song("Song 1", 180);
        Song song2 = new Song("Song 2", 240);
        
        album.add(song1);
        album.add(song2);

        // Act & Assert: Listening with a negative time should throw an IllegalArgumentException
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            album.listenToSong(0, -60);
        });
        assertEquals("Listening time cannot be negative", exception.getMessage(), "The exception message should be 'Listening time cannot be negative'");
    }

    @Test
    public void testListenToSongInvalidIndex() {
        // Initialize a new album and songs
        Album album = new Album("Greatest Hits");
        Song song1 = new Song("Song 1", 180);
        Song song2 = new Song("Song 2", 240);
        
        album.add(song1);
        album.add(song2);

        // Act & Assert: Invalid index should throw an IndexOutOfBoundsException
        IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
            album.listenToSong(2, 60);  // Song index 2 doesn't exist
        });
        assertEquals("Invalid song index", exception.getMessage(), "The exception message should be 'Invalid song index'");
    }

    @Test
    public void testListenToSongBeyondLength() {
        // Initialize a new album and songs
        Album album = new Album("Greatest Hits");
        Song song1 = new Song("Song 1", 180);
        Song song2 = new Song("Song 2", 240);
        
        album.add(song1);
        album.add(song2);

        // Act: Listen to 300 seconds of Song 2 (total length is 240, should cap at 240)
        album.listenToSong(1, 300);

        // Assert: Song 2 should have its current position updated to 240 seconds (max length)
        assertEquals(240, song2.getCurrentTime(), "The current time position of Song 2 should be capped at the song length.");
    }

    @Test
    public void testListenToMultipleSongs() {
        // Initialize a new album and songs
        Album album = new Album("Greatest Hits");
        Song song1 = new Song("Song 1", 180);
        Song song2 = new Song("Song 2", 240);
        
        album.add(song1);
        album.add(song2);

        // Act: Listen to 50 seconds of Song 1 and 100 seconds of Song 2
        album.listenToSong(0, 50);
        album.listenToSong(1, 100);

        // Assert: Song 1's current time should be 50 seconds, Song 2's should be 100 seconds
        assertEquals(50, song1.getCurrentTime(), "The current time of Song 1 should be 50 seconds.");
        assertEquals(100, song2.getCurrentTime(), "The current time of Song 2 should be 100 seconds.");
    }
}

