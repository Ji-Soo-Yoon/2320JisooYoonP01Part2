package edu.westga.comp2320.music.test.song;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import edu.westga.comp2320.music.model.Song;

/**
 * Test class for the restartSong method in the Song class.
 * Ensures that restarting a song correctly resets its playback position.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class TestRestartSong {
    
    /**
     * Tests restarting a song.
     * The current playback position should reset to 0.
     */
    @Test
    public void testRestartSongResetsPositionToZero() {
        // Arrange
        Song song = new Song("Test Song", 120, 50);
        
        // Act
        song.restartSong();
        
        // Assert
        assertEquals(0, song.getCurrentTime(), "The song should restart at position 0.");
    }
    
    /**
     * Tests restarting a song when it is already at position 0.
     * The current playback position should remain at 0.
     */
    @Test
    public void testRestartSongWhenAlreadyAtZero() {
        // Arrange
        Song song = new Song("Test Song", 120, 0);
        
        // Act
        song.restartSong();
        
        // Assert
        assertEquals(0, song.getCurrentTime(), "The song should remain at position 0.");
    }
}