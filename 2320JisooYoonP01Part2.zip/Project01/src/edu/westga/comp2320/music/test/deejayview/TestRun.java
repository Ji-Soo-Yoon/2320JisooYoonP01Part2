package edu.westga.comp2320.music.test.deejayview;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import edu.westga.comp2320.music.view.DeeJayView;

/**
 * JUnit test class for the run() method of DeeJayView.
 * Ensures the welcome message is printed correctly.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class TestRun {

    /**
     * Test run method to ensure it prints the welcome message correctly.
     */
    @Test
    public void testRunShouldPrintWelcomeMessage() {
        // Arrange
        DeeJayView view = new DeeJayView();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));

        // Act
        view.run();

        // Reset System.out to original state
        System.setOut(originalOut);

        // Assert
        String expectedOutput = "Welcome to the DeeJay Music Program!" + System.lineSeparator();
        assertEquals(expectedOutput, outputStream.toString(), "run() method should print the correct welcome message");
    }
}
