package edu.westga.comp2320.music.test.deejayview;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import edu.westga.comp2320.music.view.DeeJayView;

/**
 * JUnit test class for DeeJayView constructor.
 * Ensures the object is correctly instantiated.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class TestConstructor {

    /**
     * Test constructor to ensure a DeeJayView object is successfully created.
     */
    @Test
    public void testConstructorShouldCreateDeeJayView() {
        // Arrange
        DeeJayView view;

        // Act
        view = new DeeJayView();

        // Assert
        assertNotNull(view, "DeeJayView object should not be null");
        assertNull(view.getAlbum(), "Album should initially be null");
    }
}
