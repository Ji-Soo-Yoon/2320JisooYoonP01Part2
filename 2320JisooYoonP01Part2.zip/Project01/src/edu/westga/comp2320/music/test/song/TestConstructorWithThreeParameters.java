package edu.westga.comp2320.music.test.song;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.comp2320.music.model.Song;

/**
 * Test class for the Song constructor that initializes a song with a title, length, and current time.
 * Ensures that the constructor correctly sets the initial state.
 *
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class TestConstructorWithThreeParameters {

    /**
     * Tests the constructor with valid parameters.
     */
    @Test
    public void testValidConstructor() {
        // Arrange
        String expectedTitle = "Test Song";
        int expectedLength = 120;
        int expectedCurrentTime = 30;
        
        // Act
        Song song = new Song(expectedTitle, expectedLength, expectedCurrentTime);
        
        // Assert
        assertEquals(expectedTitle, song.getTitle());
        assertEquals(expectedLength, song.getLength());
        assertEquals(expectedCurrentTime, song.getCurrentTime());
    }

    /**
     * Tests the constructor with valid title and length but no current time position.
     */
    @Test
    public void testValidConstructorWithDefaultTime() {
        // Arrange
        String expectedTitle = "Another Song";
        int expectedLength = 200;
        int expectedCurrentTime = 0;
        
        // Act
        Song song = new Song(expectedTitle, expectedLength);
        
        // Assert
        assertEquals(expectedTitle, song.getTitle());
        assertEquals(expectedLength, song.getLength());
        assertEquals(expectedCurrentTime, song.getCurrentTime());
    }

    /**
     * Tests the constructor with a null title, expecting an exception.
     */
    @Test
    public void testConstructorWithNullTitle() {
        // Arrange & Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Song(null, 150, 50));
        assertEquals("Title cannot be null or empty", exception.getMessage());
    }

    /**
     * Tests the constructor with an empty title, expecting an exception.
     */
    @Test
    public void testConstructorWithEmptyTitle() {
        // Arrange & Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Song("", 150, 50));
        assertEquals("Title cannot be null or empty", exception.getMessage());
    }

    /**
     * Tests the constructor with a non-positive song length, expecting an exception.
     */
    @Test
    public void testConstructorWithInvalidLength() {
        // Arrange & Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Song("Invalid Length Song", 0, 10));
        assertEquals("Song length must be greater than zero", exception.getMessage());
    }

    /**
     * Tests the constructor with a negative current time position, expecting an exception.
     */
    @Test
    public void testConstructorWithNegativeCurrentTime() {
        // Arrange & Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Song("Negative Time Song", 180, -5));
        assertEquals("Invalid current time position", exception.getMessage());
    }

    /**
     * Tests the constructor with a current time position greater than the song length, expecting an exception.
     */
    @Test
    public void testConstructorWithCurrentTimeExceedingLength() {
        // Arrange & Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Song("Exceeding Time Song", 100, 150));
        assertEquals("Invalid current time position", exception.getMessage());
    }
}