package edu.westga.comp2320.music.test.song;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import edu.westga.comp2320.music.model.Song;

/**
 * Test class for the Song constructor that initializes a song with a title and length.
 * Ensures that the constructor correctly sets the initial state.
 *
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class TestConstructorWithTwoParameters {

    /**
     * Tests the constructor with a valid title and length.
     * The song should be initialized with the given title and length,
     * and the current playback position should be set to 0.
     */
    @Test
    public void testConstructorWithValidTitleAndLength() {
        // Arrange
        String title = "Test Song";
        int length = 180;

        // Act
        Song song = new Song(title, length);

        // Assert
        assertEquals(title, song.getTitle(), "The title should match the provided value.");
        assertEquals(length, song.getLength(), "The length should match the provided value.");
        assertEquals(0, song.getCurrentTime(), "The initial playback position should be 0.");
    }

    /**
     * Tests the constructor with a null title.
     * Should throw IllegalArgumentException.
     */
    @Test
    public void testConstructorWithNullTitle() {
        // Arrange & Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            new Song(null, 180);
        }, "Constructor should throw an exception for null title.");
    }

    /**
     * Tests the constructor with an empty title.
     * Should throw IllegalArgumentException.
     */
    @Test
    public void testConstructorWithEmptyTitle() {
        // Arrange & Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            new Song("", 180);
        }, "Constructor should throw an exception for empty title.");
    }

    /**
     * Tests the constructor with a negative length.
     * Should throw IllegalArgumentException.
     */
    @Test
    public void testConstructorWithNegativeLength() {
        // Arrange & Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            new Song("Valid Title", -50);
        }, "Constructor should throw an exception for negative length.");
    }

    /**
     * Tests the constructor with zero length.
     * Should throw IllegalArgumentException.
     */
    @Test
    public void testConstructorWithZeroLength() {
        // Arrange & Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            new Song("Valid Title", 0);
        }, "Constructor should throw an exception for zero length.");
    }
}