package edu.westga.comp2320.music.test.song;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import edu.westga.comp2320.music.model.Song;

/**
 * Test class for the restartSong method in the Song class.
 * Ensures that restarting a song correctly resets its playback position.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class TestListenToSong {
    
    @Test
    public void testListenToSongNormally() {
        // Arrange
        Song song = new Song("Test Song", 120);
        int listenTime = 30;
        
        // Act
        song.listenToSong(listenTime);
        
        // Assert
        assertEquals(30, song.getCurrentTime(), "Listening for 30 seconds should update position to 30s");
    }
    
    @Test
    public void testListenToSongBeyondLength() {
        // Arrange
        Song song = new Song("Test Song", 120);
        int listenTime = 150;
        
        // Act
        song.listenToSong(listenTime);
        
        // Assert
        assertEquals(120, song.getCurrentTime(), "Listening beyond length should cap at song length");
    }
    
    @Test
    public void testListenToSongExactLength() {
        // Arrange
        Song song = new Song("Test Song", 120);
        int listenTime = 120;
        
        // Act
        song.listenToSong(listenTime);
        
        // Assert
        assertEquals(120, song.getCurrentTime(), "Listening exactly the song's length should reach the end");
    }
    
    @Test
    public void testListenToSongNegativeTime() {
        // Arrange
        Song song = new Song("Test Song", 120);
        int listenTime = -10;
        
        // Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            song.listenToSong(listenTime);
        });
        assertEquals("Listening time cannot be negative", exception.getMessage(), "Negative time should throw an exception");
    }
    
    @Test
    public void testListenToSongMultipleTimes() {
        // Arrange
        Song song = new Song("Test Song", 120);
        int firstListen = 40;
        int secondListen = 30;
        
        // Act
        song.listenToSong(firstListen);
        song.listenToSong(secondListen);
        
        // Assert
        assertEquals(70, song.getCurrentTime(), "Listening twice should sum up correctly");
    }
}