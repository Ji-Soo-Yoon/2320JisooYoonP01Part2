package edu.westga.comp2320.music.test.album;

import static org.junit.jupiter.api.Assertions.*;

import edu.westga.comp2320.music.model.Song;
import edu.westga.comp2320.music.model.Album;
import org.junit.jupiter.api.Test;

public class TestConstructor {

    @Test
    public void testValidAlbumAndSongs() {
        // Arrange
        Album album = new Album("Greatest Hits");
        Song song1 = new Song("Song 1", 180);
        Song song2 = new Song("Song 2", 210);

        // Act
        album.add(song1);
        album.add(song2);

        // Assert
        assertEquals(2, album.size(), "The album should contain 2 songs.");
        assertEquals("Greatest Hits", album.getAlbumName(), "The album name should be 'Greatest Hits'");
    }

    @Test
    public void testInvalidAlbumCreationWithEmptyName() {
        // Arrange
        String invalidAlbumName = "";

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Album(invalidAlbumName);
        });
        assertEquals("Album name cannot be null or empty", exception.getMessage(), "The exception message should be 'Album name cannot be null or empty'");
    }

    @Test
    public void testInvalidSongCreationWithEmptyTitle() {
        // Arrange
        String emptyTitle = "";
        int validLength = 180;

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Song(emptyTitle, validLength);
        });
        assertEquals("Title cannot be null or empty", exception.getMessage(), "The exception message should be 'Title cannot be null or empty'");
    }

    @Test
    public void testInvalidSongCreationWithNegativeLength() {
        // Arrange
        String validTitle = "Bad Song";
        int negativeLength = -1;

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Song(validTitle, negativeLength);
        });
        assertEquals("Song length must be greater than zero", exception.getMessage(), "The exception message should be 'Song length must be greater than zero'");
    }

    @Test
    public void testInvalidSongCreationWithCurrentTimeOutOfRange() {
        // Arrange
        int invalidCurrentTime = 200;
        int validSongLength = 180;

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Song("Another Bad Song", validSongLength, invalidCurrentTime);
        });
        assertEquals("Invalid current time position", exception.getMessage(), "The exception message should be 'Invalid current time position'");
    }

    @Test
    public void testValidSongCreationWithInitialPositionZero() {
        // Arrange
        String songTitle = "Song 3";
        int songLength = 300;
        int initialPosition = 0;

        // Act
        Song song3 = new Song(songTitle, songLength, initialPosition);

        // Assert
        assertNotNull(song3, "Song should be created successfully.");
        assertEquals("Song 3", song3.getTitle(), "The song title should be 'Song 3'");
        assertEquals(0, song3.getCurrentTime(), "The initial position should be 0");
    }
}
