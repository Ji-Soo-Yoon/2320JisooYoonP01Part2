package edu.westga.comp2320.music.controller;

import edu.westga.comp2320.music.view.DeeJayView;

/**
 * The DeeJayDriver class serves as the entry point for the stand alone application.
 * It creates an instance of DeeJayView and runs the textual user interface.
 * 
 * @author Jisoo Yoon
 * @version 02/12/2025
 */
public class DeeJayDriver {
    
    /**
     * The main method to start the application.
     * 
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        DeeJayView view = new DeeJayView();
        view.run();
    }
}
